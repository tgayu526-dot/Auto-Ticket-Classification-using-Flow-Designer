AUTO TICKET CLASSIFICATION USING FLOW DESIGNER
================================================

This ZIP contains seven editable Word documents arranged in the same phase-wise folder structure as the reference ZIP:
1. Ideation Phase
2. Requirement Analysis
3. Project Design Phase
4. Project Planning Phase
5. Project Development Phase
6. Project Documentation
7. Project Demonstration

IMPORTANT:
- These are project documentation guides/templates, not proof that a ServiceNow flow has already been built or tested.
- Replace example classification rules and assignment groups with approved values from your own ServiceNow instance.
- Add screenshots and actual test results only after completing the work.
- Use a development/test instance and synthetic ticket data. Do not expose real user data, passwords, API keys, or tokens.
- The ZIP is intended to stay comfortably below a 25 MB upload limit.
